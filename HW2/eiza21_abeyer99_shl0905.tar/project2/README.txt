Michael Eizaguirre, netID: eiza21 
Arthur Beyer,       netID: abeyer99 
Shao-Hua Lo,        netID: shl0905

